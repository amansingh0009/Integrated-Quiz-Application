let questions = [
    {
        
        numb: 1,
        question: "what is the capital of France?",
        answer: "B. Paris",
        options: [
            "A. Londan",
            "B. Paris",
            "C. Berlin",
            "D. India"
        ]
    },
    {
        
        numb: 2,
        question: "What is the largest mammal in the world?",
        answer: "C. Blue Whale",
        options: [
            "A. Elephant",
            "B. Griaffe",
            "C. Blue Whale",
            "D. lion"
        ]
    },
    {
        
        numb: 3,
        question: "Which country is known as the playground of europe ?",
        answer: "C. Switzerland",
        options: [
            "A. Austria",
            "B. Holloand",
            "C. Switzerland",
            "D. Londan"
        ]
    },
    {
        
        numb: 4,
        question: "which of the following is the capital of Arunanchal pradesh ?",
        answer: "B. Itanagar",
        options: [
            "A. Dispur",
            "B. Itanagar",
            "C. Panaji",
            "D. Shimla"
        ]
    },
    {
        
        numb: 5,
        question: " What is the state Flower of Haryana?",
        answer: "B. Lotus",
        options: [
            "A. Rhondodendron",
            "B. Lotus",
            "C. Rose",
            "D. Not Declared"
        ]
    },
    {
        
        numb: 6,
        question: " Which of the Following states is not located in the north?",
        answer: "B. Jhaarkhand",
        options: [
            "A. Jammu and Kashmir",
            "B. Jhaarkhand",
            "C. Himachal Pradesh",
            "D. Punjab"
        ]
    },
    {
        
        numb: 7,
        question: "Who is current top scorer in Football?",
        answer: "B. Cristiano Ronaldo",
        options: [
            "A. Lionel Messi",
            "B. Cristiano Ronaldo",
            "C. Neymar JR",
            "D. Sunil Chetri"
        ]
    },
    {
        
        numb: 8,
        question: " Who was made the Nawab of Bengal following the Battle of Plassey?",
        answer: "A. Mir Jafar",
        options: [
            "A. Mir Jafar",
            "B. Alivardi Khan",
            "C. Sirajuddaulah",
            "D. Mir Qasim"
        ]
    },
    {
        
        numb: 9,
        question: "How many colours does sunlight consist of  ?",
        answer: "C. 7",
        options: [
            "A. 3",
            "B. 2",
            "C. 7",
            "D. 5"
        ]
    },
    {
        
        numb: 10,
        question: "Tsunami is a word in which language?",
        answer: "C. Japanese",
        options: [
            "A. Hindi",
            "B. Urdu",
            "C. Japanese",
            "D. French"
        ]
    },
    {
        
        numb: 11,
        question: "   How many types of writs can be issued under Articles 32 and 226 of the Constitution of India?",
        answer: "D. 5",
        options: [
            "A. 4",
            "B. 6",
            "C. 7",
            "D. 5"
        ]
    },
    {
        
        numb: 12,
        question: " Who is knowns as Father of  Constitution ?",
        answer: "A. Dr Bhimrao Ambedkar",
        options: [
            "A. Dr Bhimrao Ambedkar",
            "B. Mahatma Gandhi",
            "C. Narendra Modi",
            "D. Rajendra prasad"
        ]
    },
    {
        
        numb: 13,
        question: " Who was the first Chairman of the SAARC ?",
        answer: "B. Lt.Gen H.M.Ershad",
        options: [
            "A.  Mr. Zia ur Rehman",
            "B. Lt.Gen H.M.Ershad",
            "C. King Birendra",
            "D. Mrs.Indira Gandhi"  
        ]
    },
    {
        
        numb: 14,
        question: "Which bank is called bankers Bank of India?",
        answer: "A. Reverse Bank of India",
        options: [
            "A. Reverse Bank of India",
            "B. Punjab National Bank ",
            "C. State Bank of India ",
            "D. ICIC Bank"
        ]
    },

    {
        
        numb: 15,
        question: "Which is the biggest continent in the world ?",
        answer: "B. Asia",
        options: [
            "A. North America",
            "B. Asia",
            "C. Africa",
            "D. Austria"
        ]
    },
 

        ];