document.write("Hello <br>");
document.write("<b>Sam</b> How are you <br>");